import React, { useState } from "react";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonItem,
  IonLabel,
  IonInput,
  IonButton,
} from "@ionic/react";

const Cliente: React.FC = () => {
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    edad: "",
    correo: "",
  });

  const handleChange = (e: any) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Cliente</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Registro de Cliente</IonCardTitle>
          </IonCardHeader>
          <IonItem>
            <IonLabel position="floating">Nombre</IonLabel>
            <IonInput name="nombre" value={form.nombre} onIonChange={handleChange} />
          </IonItem>
          <IonItem>
            <IonLabel position="floating">Apellido</IonLabel>
            <IonInput name="apellido" value={form.apellido} onIonChange={handleChange} />
          </IonItem>
          <IonItem>
            <IonLabel position="floating">Edad</IonLabel>
            <IonInput name="edad" value={form.edad} onIonChange={handleChange} type="number" />
          </IonItem>
          <IonItem>
            <IonLabel position="floating">Correo</IonLabel>
            <IonInput name="correo" value={form.correo} onIonChange={handleChange} type="email" />
          </IonItem>
          <div className="ion-padding">
          <IonButton className="rosa-pastel">Agregar</IonButton>
<IonButton className="lila-pastel">Modificar</IonButton>
<IonButton className="melocoton-pastel">Eliminar</IonButton>
<IonButton className="celeste-pastel">Consultar</IonButton>


          </div>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Cliente;
